export {default as headsetImage} from "./headset.png";
export {default as pencilImage} from "./pencil.png";
export {default as shieldImage} from "./shield.png";

export {default as portfolio1 } from './portfolio-1.jpg'
export {default as portfolio2 } from './portfolio-2.jpg'
export {default as portfolio3 } from './portfolio-3.png'
export {default as portfolio4 } from './portfolio-4.png'
export {default as portfolio5 } from './portfolio-5.png'
export {default as portfolio6 } from './portfolio-6.png'

export { default as client1 } from "./client-1.jpg";
export { default as client2 } from "./client-2.jpg";
export { default as client3 } from "./client-3.jpg";
export { default as client4 } from "./client-4.jpg";
export { default as client5 } from "./client-5.jpg";
export { default as client6 } from "./client-6.jpg";
