import React from 'react'
import banner from './../assets/slider-3.png';
import BoxAnimation from '@/assets/BoxAnimation';
import { HeroParallaxDemo } from './HeroParallaxDemo';


const Home = () => {
  return (
    <div className="">
      <HeroParallaxDemo />
    </div>
  )
}

export default Home
