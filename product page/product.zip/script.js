// function changeImage(imageSrc) {
//     document.getElementById("main-image").src = imageSrc;
// }

// function addToCart() {
//     let quantity = document.getElementById("quantity").value;
//     let confirmationMessage = document.getElementById("confirmation-message");
    
//     // Show confirmation message
//     confirmationMessage.style.display = 'block';
//     confirmationMessage.textContent = `Product added to cart! Quantity: ${quantity}`;

//     // Hide the message after 3 seconds
//     setTimeout(() => {
//         confirmationMessage.style.display = 'none';
//     }, 3000);
// }




// function changeImage(imageSrc) {
//     document.getElementById("main-image").src = imageSrc;
// }

// function addToCart() {
//     let quantity = document.getElementById("quantity").value;
//     let confirmationMessage = document.getElementById("confirmation-message");

//     // Show confirmation message
//     confirmationMessage.style.display = 'block';
//     confirmationMessage.textContent = `Product added to cart! Quantity: ${quantity}`;

//     // Hide the message after 3 seconds
//     setTimeout(() => {
//         confirmationMessage.style.display = 'none';
//     }, 3000);
// }

// function scrollThumbnails(direction) {
//     const thumbnailContainer = document.getElementById('thumbnail-container');
//     const scrollAmount = 60; // Adjust this value to scroll by more or less
//     if (direction === 'left') {
//         thumbnailContainer.scrollLeft -= scrollAmount;
//     } else if (direction === 'right') {
//         thumbnailContainer.scrollLeft += scrollAmount;
//     }
// }




function changeImage(imageSrc) {
    document.getElementById("main-image").src = imageSrc;
}

function addToCart() {
    let quantity = document.getElementById("quantity").value;
    let confirmationMessage = document.getElementById("confirmation-message");

    // Show confirmation message
    confirmationMessage.style.display = 'block';
    confirmationMessage.textContent = `Product added to cart! Quantity: ${quantity}`;

    // Hide the message after 3 seconds
    setTimeout(() => {
        confirmationMessage.style.display = 'none';
    }, 3000);
}

function scrollThumbnails(direction) {
    const thumbnailContainer = document.getElementById('thumbnail-container');
    const thumbnails = document.querySelectorAll('.thumbnail');
    const scrollAmount = 120; // Adjust this value if needed

    if (direction === 'left') {
        // If scrolled to the first image, move to the last image
        if (thumbnailContainer.scrollLeft <= 0) {
            thumbnailContainer.scrollLeft = thumbnailContainer.scrollWidth;
        } else {
            thumbnailContainer.scrollLeft -= scrollAmount;
        }
    } else if (direction === 'right') {
        // If scrolled to the last image, move back to the first image
        if (thumbnailContainer.scrollLeft + thumbnailContainer.clientWidth >= thumbnailContainer.scrollWidth) {
            thumbnailContainer.scrollLeft = 0;
        } else {
            thumbnailContainer.scrollLeft += scrollAmount;
        }
    }
}
