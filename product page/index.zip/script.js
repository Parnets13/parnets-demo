function changeImage(seed) {
    const newImageUrl = `https://picsum.photos/seed/${seed}/500/500`;
    document.getElementById("main-image").src = newImageUrl;
}

function addToCart() {
    let quantity = document.getElementById("quantity").value;
    let confirmationMessage = document.getElementById("confirmation-message");

    // Show confirmation message
    confirmationMessage.style.display = 'block';
    confirmationMessage.textContent = `Product added to cart! Quantity: ${quantity}`;

    // Hide the message after 3 seconds
    setTimeout(() => {
        confirmationMessage.style.display = 'none';
    }, 3000);
}

function scrollThumbnails(direction) {
    const thumbnailContainer = document.getElementById('thumbnail-container');
    const scrollAmount = 120; // Adjust this value to scroll by more or less

    if (direction === 'left') {
        if (thumbnailContainer.scrollLeft <= 0) {
            thumbnailContainer.scrollLeft = thumbnailContainer.scrollWidth;
        } else {
            thumbnailContainer.scrollLeft -= scrollAmount;
        }
    } else if (direction === 'right') {
        if (thumbnailContainer.scrollLeft + thumbnailContainer.clientWidth >= thumbnailContainer.scrollWidth) {
            thumbnailContainer.scrollLeft = 0;
        } else {
            thumbnailContainer.scrollLeft += scrollAmount;
        }
    }
}
